/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *logoLabel;
    QGroupBox *groupBox;
    QLineEdit *inputnumber;
    QComboBox *from;
    QComboBox *to;
    QLabel *fromlabel;
    QLabel *tolabel;
    QPushButton *SWAP;
    QPushButton *CONVERT;
    QPushButton *RESET;
    QLineEdit *result_line;
    QLabel *result_label;
    QPushButton *COPY;
    QPushButton *FILE_INPUT;
    QPushButton *FILE_SAVE;
    QPushButton *instruction;
    QMenuBar *menubar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 600);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        centralwidget->setStyleSheet(QString::fromUtf8("QWidget {\n"
"    background: qlineargradient(\n"
"        x1: 0, y1: 0,\n"
"        x2: 0, y2: 1,\n"
"        stop: 0 #737373,\n"
"        stop: 1 #262626\n"
"    );\n"
"}"));
        logoLabel = new QLabel(centralwidget);
        logoLabel->setObjectName("logoLabel");
        logoLabel->setGeometry(QRect(300, 20, 191, 121));
        logoLabel->setStyleSheet(QString::fromUtf8("QWidget {\n"
"    background: qlineargradient(\n"
"        x1: 0, y1: 0,\n"
"        x2: 0, y2: 1,\n"
"        stop: 0 #737373,\n"
"        stop: 1 #262626\n"
"    );\n"
"}\n"
"QLabel#logoLabel {\n"
"    background-color: transparent;\n"
"    border: none;\n"
"}"));
        logoLabel->setPixmap(QPixmap(QString::fromUtf8("C:/Users/Vlad/Downloads/logo (1).png")));
        logoLabel->setScaledContents(true);
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(60, 160, 681, 411));
        groupBox->setStyleSheet(QString::fromUtf8("QGroupBox#groupBox{\n"
"    background-color: transparent;         /* \320\277\320\276\320\262\320\275\321\226\321\201\321\202\321\216 \320\277\321\200\320\276\320\267\320\276\321\200\320\270\320\271 \321\204\320\276\320\275 */\n"
"    border: 2px solid #868686;             /* \321\201\321\226\321\200\320\270\320\271 \320\261\320\276\321\200\320\264\320\265\321\200 */\n"
"    border-radius: 30px;                   /* \320\276\320\272\321\200\321\203\320\263\320\273\320\265\320\275\320\275\321\217 */\n"
"    margin-top: 0px;                       /* \321\217\320\272\321\211\320\276 \320\275\320\265\320\274\320\260\321\224 \320\267\320\260\320\263\320\276\320\273\320\276\320\262\320\272\320\260 */\n"
"}\n"
"\n"
"QGroupBox#groupBox {\n"
"    color: transparent;                    /* \320\277\321\200\320\270\321\205\320\276\320\262\321\203\321\224\320\274\320\276 \320\267\320\260\320\263\320\276\320\273\320\276\320\262\320\276\320\272, \321\217\320\272\321\211\320\276 \320\262\320\270\320\277\320\260\320\264\320\272"
                        "\320\276\320\262\320\276 \321\224 */\n"
"    background: transparent;\n"
"}"));
        inputnumber = new QLineEdit(groupBox);
        inputnumber->setObjectName("inputnumber");
        inputnumber->setGeometry(QRect(170, 20, 331, 41));
        inputnumber->setStyleSheet(QString::fromUtf8("QLineEdit#inputnumber {\n"
"    background-color: transparent;         \n"
"    border: 2px solid #868686;             \n"
"    border-radius: 15px;\n"
"	font-size: 30px;\n"
"	text-align: center;\n"
"	padding-left: 45px;\n"
"	color: #828282; \n"
"	font-weight: bold;              \n"
"}"));
        from = new QComboBox(groupBox);
        from->addItem(QString());
        from->setObjectName("from");
        from->setGeometry(QRect(40, 110, 161, 131));
        from->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    background-color: transparent;\n"
"    border: 2px solid #868686;\n"
"    border-radius: 15px;\n"
"    padding: 15px;\n"
"    color: white; \n"
"}\n"
"QComboBox QAbstractItemView {\n"
"    font-size: 25px;\n"
"    font-weight: bold;\n"
"    color: white;\n"
"    background-color: #3a3a3a;  /* \320\272\320\276\320\273\321\226\321\200 \320\262\320\270\320\277\320\260\320\264\320\260\321\216\321\207\320\276\320\263\320\276 \321\201\320\277\320\270\321\201\320\272\321\203 */\n"
"    selection-background-color: #5a5a5a;  /* \320\277\321\200\320\270 \320\275\320\260\320\262\320\265\320\264\320\265\320\275\320\275\321\226/\320\262\320\270\320\261\320\276\321\200\321\226 */\n"
"    border: none;\n"
"}"));
        to = new QComboBox(groupBox);
        to->addItem(QString());
        to->setObjectName("to");
        to->setGeometry(QRect(480, 110, 161, 131));
        to->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    background-color: transparent;\n"
"    border: 2px solid #868686;\n"
"    border-radius: 15px;\n"
"    padding: 15px;\n"
"    color: white; \n"
"}\n"
"QComboBox QAbstractItemView {\n"
"    font-size: 25px;\n"
"    font-weight: bold;\n"
"    color: white;\n"
"    background-color: #3a3a3a;  /* \320\272\320\276\320\273\321\226\321\200 \320\262\320\270\320\277\320\260\320\264\320\260\321\216\321\207\320\276\320\263\320\276 \321\201\320\277\320\270\321\201\320\272\321\203 */\n"
"    selection-background-color: #5a5a5a;  /* \320\277\321\200\320\270 \320\275\320\260\320\262\320\265\320\264\320\265\320\275\320\275\321\226/\320\262\320\270\320\261\320\276\321\200\321\226 */\n"
"    border: none;\n"
"}"));
        fromlabel = new QLabel(groupBox);
        fromlabel->setObjectName("fromlabel");
        fromlabel->setGeometry(QRect(40, 90, 49, 21));
        fromlabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 20px;\n"
"    color: #828282;\n"
"	background: transparent;\n"
"}"));
        tolabel = new QLabel(groupBox);
        tolabel->setObjectName("tolabel");
        tolabel->setGeometry(QRect(620, 90, 21, 21));
        tolabel->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 20px;\n"
"    color: #828282;\n"
"	background: transparent;\n"
"}"));
        SWAP = new QPushButton(groupBox);
        SWAP->setObjectName("SWAP");
        SWAP->setGeometry(QRect(270, 100, 141, 41));
        SWAP->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 8px;\n"
"    border: 2px solid #868686;\n"
"    color: #828282;\n"
"	padding-left:5px;\n"
"    font-size: 20px;\n"
"    font-weight: bold;\n"
"    text-align: left; /* \321\202\320\265\320\272\321\201\321\202 \320\273\321\226\320\262\320\276\321\200\321\203\321\207, \321\211\320\276\320\261 \320\272\320\260\321\200\321\202\320\270\320\275\320\272\320\260 \320\261\321\203\320\273\320\260 \320\277\320\265\321\200\320\265\320\264 \320\275\320\270\320\274 */\n"
"	background: transparent;\n"
"}\n"
"\n"
"QPushButton::icon {\n"
"    position: absolute;\n"
"    left: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(255, 255, 255, 0.05);\n"
"}"));
        QIcon icon;
        icon.addFile(QString::fromUtf8("C:/Users/Vlad/Downloads/SWAP.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        SWAP->setIcon(icon);
        SWAP->setIconSize(QSize(35, 35));
        CONVERT = new QPushButton(groupBox);
        CONVERT->setObjectName("CONVERT");
        CONVERT->setGeometry(QRect(270, 150, 141, 41));
        CONVERT->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 8px;\n"
"    border: 2px solid #868686;\n"
"    color: #828282;\n"
"    font-size: 20px;\n"
"	padding-left:5px;\n"
"    font-weight: bold;\n"
"    text-align: left; /* \321\202\320\265\320\272\321\201\321\202 \320\273\321\226\320\262\320\276\321\200\321\203\321\207, \321\211\320\276\320\261 \320\272\320\260\321\200\321\202\320\270\320\275\320\272\320\260 \320\261\321\203\320\273\320\260 \320\277\320\265\321\200\320\265\320\264 \320\275\320\270\320\274 */\n"
"	background: transparent;\n"
"}\n"
"\n"
"QPushButton::icon {\n"
"    position: absolute;\n"
"    left: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(255, 255, 255, 0.05);\n"
"}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("C:/Users/Vlad/Downloads/CONVERT.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        CONVERT->setIcon(icon1);
        CONVERT->setIconSize(QSize(30, 30));
        RESET = new QPushButton(groupBox);
        RESET->setObjectName("RESET");
        RESET->setGeometry(QRect(270, 200, 141, 41));
        RESET->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 8px;\n"
"    border: 2px solid #868686;\n"
"    color: #828282;\n"
"    padding-left:5px;\n"
"    font-size: 20px;\n"
"    font-weight: bold;\n"
"    text-align: left; /* \321\202\320\265\320\272\321\201\321\202 \320\273\321\226\320\262\320\276\321\200\321\203\321\207, \321\211\320\276\320\261 \320\272\320\260\321\200\321\202\320\270\320\275\320\272\320\260 \320\261\321\203\320\273\320\260 \320\277\320\265\321\200\320\265\320\264 \320\275\320\270\320\274 */\n"
"	background: transparent;\n"
"}\n"
"\n"
"QPushButton::icon {\n"
"    position: absolute;\n"
"    left: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(255, 255, 255, 0.05);\n"
"}"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("C:/Users/Vlad/Downloads/RESET.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        RESET->setIcon(icon2);
        RESET->setIconSize(QSize(35, 35));
        result_line = new QLineEdit(groupBox);
        result_line->setObjectName("result_line");
        result_line->setEnabled(true);
        result_line->setGeometry(QRect(60, 300, 561, 101));
        result_line->setStyleSheet(QString::fromUtf8("QLineEdit#result_line{\n"
"    background-color: transparent;         \n"
"    border: 2px solid #868686;             \n"
"    border-radius: 15px;\n"
"	font-size: 15px;\n"
"	padding-left: 15px;\n"
"	paddint-right: 15px;\n"
"	color: #828282; \n"
"	font-weight: regular;              \n"
"}"));
        result_line->setReadOnly(true);
        result_label = new QLabel(groupBox);
        result_label->setObjectName("result_label");
        result_label->setGeometry(QRect(280, 260, 121, 41));
        result_label->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    font-size: 35px;\n"
"    color: #828282;\n"
"	background: transparent;\n"
"}"));
        COPY = new QPushButton(groupBox);
        COPY->setObjectName("COPY");
        COPY->setGeometry(QRect(550, 280, 71, 16));
        COPY->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 8px;\n"
"    border: 2px solid #868686;\n"
"    color: #828282;\n"
"    font-size: 15px;\n"
"	padding-left:5px;\n"
"    font-weight: bold;\n"
"    text-align: left; /* \321\202\320\265\320\272\321\201\321\202 \320\273\321\226\320\262\320\276\321\200\321\203\321\207, \321\211\320\276\320\261 \320\272\320\260\321\200\321\202\320\270\320\275\320\272\320\260 \320\261\321\203\320\273\320\260 \320\277\320\265\321\200\320\265\320\264 \320\275\320\270\320\274 */\n"
"	background: transparent;\n"
"}\n"
"QPushButton#COPY {\n"
"	background: none;\n"
"	border-radius: 0px;\n"
"    border: 0px solid #868686;\n"
"	\n"
"}\n"
"\n"
"QPushButton::icon {\n"
"    position: absolute;\n"
"    left: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(255, 255, 255, 0.05);\n"
"}"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("C:/Users/Vlad/Downloads/Group (1).png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        COPY->setIcon(icon3);
        COPY->setIconSize(QSize(15, 15));
        FILE_INPUT = new QPushButton(groupBox);
        FILE_INPUT->setObjectName("FILE_INPUT");
        FILE_INPUT->setGeometry(QRect(170, 0, 71, 21));
        FILE_INPUT->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 8px;\n"
"    border: 2px solid #868686;\n"
"    color: #828282;\n"
"    font-size: 15px;\n"
"	padding-left:5px;\n"
"    font-weight: bold;\n"
"    text-align: left; /* \321\202\320\265\320\272\321\201\321\202 \320\273\321\226\320\262\320\276\321\200\321\203\321\207, \321\211\320\276\320\261 \320\272\320\260\321\200\321\202\320\270\320\275\320\272\320\260 \320\261\321\203\320\273\320\260 \320\277\320\265\321\200\320\265\320\264 \320\275\320\270\320\274 */\n"
"	background: transparent;\n"
"}\n"
"QPushButton#FILE_INPUT {\n"
"	background: none;\n"
"	border-radius: 0px;\n"
"    border: 0px solid #868686;\n"
"	\n"
"}\n"
"\n"
"QPushButton::icon {\n"
"    position: absolute;\n"
"    left: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(255, 255, 255, 0.05);\n"
"}"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("C:/Users/Vlad/Downloads/folder 1.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        FILE_INPUT->setIcon(icon4);
        FILE_INPUT->setIconSize(QSize(15, 15));
        FILE_SAVE = new QPushButton(groupBox);
        FILE_SAVE->setObjectName("FILE_SAVE");
        FILE_SAVE->setGeometry(QRect(60, 280, 71, 21));
        FILE_SAVE->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 8px;\n"
"    border: 2px solid #868686;\n"
"    color: #828282;\n"
"    font-size: 15px;\n"
"	padding-left:5px;\n"
"    font-weight: bold;\n"
"    text-align: left; /* \321\202\320\265\320\272\321\201\321\202 \320\273\321\226\320\262\320\276\321\200\321\203\321\207, \321\211\320\276\320\261 \320\272\320\260\321\200\321\202\320\270\320\275\320\272\320\260 \320\261\321\203\320\273\320\260 \320\277\320\265\321\200\320\265\320\264 \320\275\320\270\320\274 */\n"
"	background: transparent;\n"
"}\n"
"QPushButton#FILE_SAVE {\n"
"	background: none;\n"
"	border-radius: 0px;\n"
"    border: 0px solid #868686;\n"
"	\n"
"}\n"
"\n"
"QPushButton::icon {\n"
"    position: absolute;\n"
"    left: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(255, 255, 255, 0.05);\n"
"}"));
        FILE_SAVE->setIcon(icon4);
        FILE_SAVE->setIconSize(QSize(15, 15));
        instruction = new QPushButton(groupBox);
        instruction->setObjectName("instruction");
        instruction->setGeometry(QRect(10, 10, 41, 31));
        instruction->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 8px;\n"
"    border: 2px solid #868686;\n"
"    color: #828282;\n"
"    font-size: 15px;\n"
"	padding-left:5px;\n"
"    font-weight: bold;\n"
"    text-align: left; /* \321\202\320\265\320\272\321\201\321\202 \320\273\321\226\320\262\320\276\321\200\321\203\321\207, \321\211\320\276\320\261 \320\272\320\260\321\200\321\202\320\270\320\275\320\272\320\260 \320\261\321\203\320\273\320\260 \320\277\320\265\321\200\320\265\320\264 \320\275\320\270\320\274 */\n"
"	background: transparent;\n"
"}\n"
"QPushButton#instruction {\n"
"	background: none;\n"
"	border-radius: 0px;\n"
"    border: 0px solid #868686;\n"
"	\n"
"}\n"
"\n"
"QPushButton::icon {\n"
"    position: absolute;\n"
"    left: 10px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgba(255, 255, 255, 0.05);\n"
"}"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("C:/Users/Vlad/Downloads/information-pamphlet 1.png"), QSize(), QIcon::Mode::Normal, QIcon::State::Off);
        instruction->setIcon(icon5);
        instruction->setIconSize(QSize(32, 32));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 22));
        MainWindow->setMenuBar(menubar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        logoLabel->setText(QString());
        groupBox->setTitle(QString());
        inputnumber->setPlaceholderText(QCoreApplication::translate("MainWindow", "ENTER NUMBER", nullptr));
        from->setItemText(0, QCoreApplication::translate("MainWindow", "---", nullptr));

        to->setItemText(0, QCoreApplication::translate("MainWindow", "---", nullptr));

        fromlabel->setText(QCoreApplication::translate("MainWindow", "From", nullptr));
        tolabel->setText(QCoreApplication::translate("MainWindow", "To", nullptr));
        SWAP->setText(QCoreApplication::translate("MainWindow", "SWAP", nullptr));
        CONVERT->setText(QCoreApplication::translate("MainWindow", "CONVERT", nullptr));
        RESET->setText(QCoreApplication::translate("MainWindow", "RESET", nullptr));
        result_line->setText(QString());
        result_line->setPlaceholderText(QString());
        result_label->setText(QCoreApplication::translate("MainWindow", "RESULT", nullptr));
        COPY->setText(QCoreApplication::translate("MainWindow", "COPY", nullptr));
        FILE_INPUT->setText(QCoreApplication::translate("MainWindow", "FILE", nullptr));
        FILE_SAVE->setText(QCoreApplication::translate("MainWindow", "SAVE", nullptr));
        instruction->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
